import { ProductsService } from './products.service';
import { UserService } from './users.service';


export const Services = [ProductsService, UserService];