import { 
    ProductsService, 
    UserService, 
    SidebarItemsManager 
} from '../services/index';


export const Services = [
    ProductsService,
    UserService,
    SidebarItemsManager
];