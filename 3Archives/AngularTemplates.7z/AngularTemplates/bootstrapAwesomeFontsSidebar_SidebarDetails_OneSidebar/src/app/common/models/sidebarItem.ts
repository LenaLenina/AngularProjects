export class SidebarItem {
    constructor(
        public name: string,
        public url: string
    ) { }
}